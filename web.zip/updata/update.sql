ALTER TABLE  `openvpn` ADD  `fwqid` INT NULL DEFAULT  '1' AFTER  `dlid` ,
ADD  `notes` VARCHAR( 255 ) NULL AFTER  `fwqid`