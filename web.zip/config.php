<?php
/*数据库配置*/
$host = "localhost"; //MYSQL主机
$port = 3306; //MYSQL主机
$user = "root"; //MYSQL用户
$pwd ="root"; //MYSQL密码
$dbname = "ov"; //数据库名
$adminuser="admin";//管理员用户名
$adminpass="123456";//管理员密码
//JXL_add for 2016-04-16 begin
$conf_rate="0";//推荐人返现折扣率，如：0为不返现，1为全额返现，返点5%填0.05，返点10%填0.1，正常情况下，取值范围（0~1），请须知
//JXL_add for 2016-04-16 end
?>